import time

print "RUNNING FG2"
time.sleep(300)
print "FINISHED FG2"
