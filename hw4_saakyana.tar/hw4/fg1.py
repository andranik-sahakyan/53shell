import time

print "RUNNING FG1"
time.sleep(300)
print "FINISHED FG1"
